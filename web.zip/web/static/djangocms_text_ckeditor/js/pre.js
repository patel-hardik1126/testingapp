(function ($) {
    $(function () {
